﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpressions
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Employee> eList = new List<Employee>()
            {
                new Employee(){empNo=101, empName ="Nikhil", empDesigantion="Consultatnt", empIsPermenant=true, empSalary=120 },
                new Employee(){empNo=102, empName ="Priya", empDesigantion="Accounts", empIsPermenant=false, empSalary=2000 },
                new Employee(){empNo=103, empName ="Riya", empDesigantion="HR", empIsPermenant=true, empSalary=100 },
                new Employee(){empNo=104, empName ="Jiya", empDesigantion="Consultatnt", empIsPermenant=true, empSalary=230 },
                new Employee(){empNo=105, empName ="Diya", empDesigantion="Consultatnt", empIsPermenant=true, empSalary=900 },
                new Employee(){empNo=106, empName ="Ramesh", empDesigantion="Consultatnt", empIsPermenant=true, empSalary=150 },
                new Employee(){empNo=107, empName ="Suresh", empDesigantion="Accounts", empIsPermenant=false, empSalary=239 },
                new Employee(){empNo=108, empName ="Aman", empDesigantion="Consultatnt", empIsPermenant=true, empSalary=890 },
                new Employee(){empNo=109, empName ="Mohan", empDesigantion="Consultatnt", empIsPermenant=true, empSalary=255 },
                new Employee(){empNo=110, empName ="Rohan", empDesigantion="HR", empIsPermenant=true, empSalary=365 },
                new Employee(){empNo=111, empName ="Sohan", empDesigantion="HR", empIsPermenant=true, empSalary=963 },
                new Employee(){empNo=112, empName ="Karan", empDesigantion="Accounts", empIsPermenant=false, empSalary=789 },
                new Employee(){empNo=113, empName ="Kirthi", empDesigantion="Consultatnt", empIsPermenant=true, empSalary=365 },
                new Employee(){empNo=114, empName ="Arjun", empDesigantion="Consultatnt", empIsPermenant=true, empSalary=456 },
                new Employee(){empNo=115, empName ="Mahesh", empDesigantion="Consultatnt", empIsPermenant=true, empSalary=3698 },
                new Employee(){empNo=116, empName ="Rohit", empDesigantion="HR", empIsPermenant=true, empSalary=7896 },
                new Employee(){empNo=117, empName ="Vijay", empDesigantion="Accounts", empIsPermenant=false, empSalary=1236 },
            };
            Dictionary<int, Employee> empDictionatry = new Dictionary<int, Employee>();

            Employee emp1 = new Employee() { empNo = 101, empName = "Nikhil", empSalary = 2300, empDesigantion = "Consultant", empIsPermenant = true };
            Employee emp2 = new Employee() { empNo = 101, empName = "Nikhil", empSalary = 2300, empDesigantion = "Consultant", empIsPermenant = true };
            Employee emp3 = new Employee() { empNo = 101, empName = "Nikhil", empSalary = 2300, empDesigantion = "Consultant", empIsPermenant = true };
            Employee emp4 = new Employee() { empNo = 101, empName = "Nikhil", empSalary = 2300, empDesigantion = "Consultant", empIsPermenant = true };
            Employee emp5 = new Employee() { empNo = 101, empName = "Nikhil", empSalary = 2300, empDesigantion = "Consultant", empIsPermenant = true };

            empDictionatry.Add(emp1.empNo, emp1);
            empDictionatry.Add(emp2.empNo, emp2);
            empDictionatry.Add(emp3.empNo, emp3);
            empDictionatry.Add(emp4.empNo, emp4);




            //  var totalEmp = eList.Count; //part of every collection

            double highSalary =0;
            foreach (var item in eList)
            {
                if (item.empSalary > highSalary)
                {
                    highSalary = item.empSalary;
                }
            }

            //Console.WriteLine("Code Highest sal " + highSalary);

            //var highestSal = eList.Max(em => em.empSalary);

            //Console.WriteLine("Lambda Highest Sal " + highestSal);

            //var TotalSal = eList.Sum(em => em.empSalary);
            //var totalHR = eList.Count(em => em.empDesigantion == "HR");
            //var permenantEmp = eList.Count(e => e.empIsPermenant == true && e.empDesigantion == "HR");


            //Console.WriteLine(TotalSal);
            //Console.WriteLine(totalHR);
            //Console.WriteLine(permenantEmp);

            var highestSal = eList.Sum(em => em.empSalary);

            Console.WriteLine("Lambda Highest Sal " + highestSal);

            var TotalSal = eList.Sum(em => em.empSalary);
            var totalHRSal = eList.Where(em => em.empDesigantion == "HR").Sum(e => e.empSalary);
            Console.WriteLine("HR " + totalHRSal);



        }
    }
}
