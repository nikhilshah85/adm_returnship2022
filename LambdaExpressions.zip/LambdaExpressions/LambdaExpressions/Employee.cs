﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpressions
{
    internal class Employee
    {
        public int empNo { get; set; }
        public string empName { get; set; }
        public string empDesigantion { get; set; }
        public double empSalary { get; set; }
        public bool empIsPermenant { get; set; }
    }
}
