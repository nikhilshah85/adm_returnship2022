﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using angularCoreAuth.Models;
namespace angularCoreAuth.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValidateuserController : ControllerBase
    {
        ProductdbContext db = new ProductdbContext();


        [HttpGet]
        [Route("login")]
        public bool Validateuser(string uname, string password)
        {
            var result = (from a in db.Logins
                          where a.Username == uname && a.Password == password
                          select a).Count();

            if (result == 1)
            {
                return true;
            }
            else
            {
                return false;
            }


        }
    }
}
