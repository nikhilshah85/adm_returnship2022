﻿using System;
using System.Collections.Generic;

namespace angularCoreAuth.Models
{
    public partial class Login
    {
        public string? Username { get; set; }
        public string? Password { get; set; }
    }
}
