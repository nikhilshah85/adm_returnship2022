import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class ValidateuserService implements CanActivate {


  _http: HttpClient;
  isValidUser: any = false;



  constructor(_httpREF: HttpClient) {
    this._http = _httpREF;
  }




    canActivate(uName:any, pwd:any): boolean  {

      this._http.get('https://localhost:7033/api/Validateuser/login?uname=' + uName + '&password=' + pwd).subscribe((res) => {
        console.log(res);
        this.isValidUser = res;
      })
      return this.isValidUser;

    }
}
