import { Component, OnInit } from '@angular/core';
import { ValidateuserService } from '../services/validateuser.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  _validate: ValidateuserService;

  constructor(_validateREF: ValidateuserService) {
    this._validate = _validateREF;
    
    
}




  ngOnInit(): void {
  }

}
