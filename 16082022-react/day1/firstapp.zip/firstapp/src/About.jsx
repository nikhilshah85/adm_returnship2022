import { Component } from "react";

export class About extends Component
{

    render(){
        return(<div>
            <h1> About Us </h1>
            <p> Welcome to About us page, this is a page which sayings something about our organization and culture</p>
            <p> More Info Coming Soon</p>
        </div>)

    }

}

export default About