import { Component } from "react";

export class Products extends Component
{

        productCategory = ['Cold-Drinks','Electronics','Cloths','Shoes','Accessories','Furniture','Laptops'];

        employeeDetails = [

            {empNo:101,empName:'Karan',empDesignation:'Sales',empSalary:7000,empIsPermenant:true},
            {empNo:102,empName:'Rahul',empDesignation:'HR',empSalary:17000,empIsPermenant:true},
            {empNo:103,empName:'Priya',empDesignation:'Sales',empSalary:12000,empIsPermenant:false},
            {empNo:104,empName:'Riya',empDesignation:'Sales',empSalary:700,empIsPermenant:true},
            {empNo:105,empName:'Jiya',empDesignation:'HR',empSalary:12000,empIsPermenant:true},
            {empNo:106,empName:'Mohan',empDesignation:'Sales',empSalary:89000,empIsPermenant:true},
            {empNo:107,empName:'Rohan',empDesignation:'Sales',empSalary:36000,empIsPermenant:false},
            {empNo:108,empName:'Sohan',empDesignation:'Accounts',empSalary:5600,empIsPermenant:true},
            {empNo:109,empName:'Rohit',empDesignation:'Accounts',empSalary:36000,empIsPermenant:false},
        
        ]
        render(){
            return(<div>

                    <ul>
                        { this.productCategory.map( p => <li> { p } </li>) }
                    </ul>

                    <select>
                        {this.productCategory.map( p => <option> { p } </option>)}
                    </select>              
            </div>)
        }

}
export default Products;