import logo from './logo.svg';
import Home from './Home';
import About from './About';
import Contact from './Contacct';
import Products from './Products';

function App() {
  return (
    <div className="App">
      <h1> Hello and Welcome to React</h1>
      <p> This is my Very first application on React and this going to be an exciting Journey </p>

   <Products></Products>


    </div>

    
  );
}

export default App;
