import { Component } from "react";

export class Contact extends Component
{
    contactNumber = '0900';
    contactEmail = 'contactus@training.com';
    developerName = 'Nikhil';
    monthlyBasic  = 2000;

    greetings()
    {
        alert('Welcome to Functions in React');
    }

    render(){
        return(<div>
            <h2> Phone : { this.contactNumber }</h2>
            <h2> Email : { this.contactEmail }</h2>
            <h2> Developed By : { this.developerName }</h2>
            <button onClick={ this.greetings}> Greet </button>

            <h2> Addition of My Fav Numbers is : { 5 + 4 }</h2>

            <p> Basic : { this.monthlyBasic } </p>
            <p> Bonus : { this.monthlyBasic * 10 /100} </p>
            <p> HRA : { this.monthlyBasic *  7.5 / 100} </p>

            <p> Annual CTC : {(this.monthlyBasic * 12) + (this.monthlyBasic *  0.1  * 12 )}       </p>
        </div>)
    }


}

export default Contact;