import { Component } from "react";

export class Home  extends Component
{
    //properties
    //methods
    //constructors
    render(){
        //local variables 
        return(<div>
            <h1> Weclome to Home Component of My React APP</h1>
            <h3> This is the Home page and some more details will be coming up here very soon </h3>
            <h3> This component is going to be used in APP component </h3>
            <h3> This component is now a child component to APP component - which is now a parent component</h3>
        </div>)
    }
}
export default Home;