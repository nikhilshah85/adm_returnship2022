﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace ado_net_demo
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("~~~~~~~~~~~~~~~~~~~  Welcome to Product Management APP ~~~~~~~~~~~~~~~~~~~~~~~~");

            #region Login

            SqlConnection con = null;
            SqlCommand cmd = null;
            try
            {
                con = new SqlConnection(@"server=WIN8\NIKHILINSTANCE;database=trainingDB;user id=sa;password=Password1234");
                cmd = new SqlCommand("select count(*) from userDetails where userName=@uName and password=@pwd", con);

                Console.WriteLine("Enter User Name");
                string uName = Console.ReadLine();
                Console.WriteLine("Enter Password");
                string pwd = Console.ReadLine();

                cmd.Parameters.AddWithValue("@uName", uName);
                cmd.Parameters.AddWithValue("@pwd", pwd);

                con.Open();
                int result = (int)cmd.ExecuteScalar();
                if (result == 1)
                {
                    Console.Clear();

                    bool continueAPP = true;

                    while (continueAPP)
                    {
                        Console.Clear();
                        Console.WriteLine("~~~~~~~~~~~~~~~~~~~  Welcome to Product Management APP ~~~~~~~~~~~~~~~~~~~~~~~~``");

                        Console.WriteLine("  ----------- Hi " + uName + " ----------------------");
                        Console.WriteLine("1. Add a New Product");
                        Console.WriteLine("2. Update a  Product");
                        Console.WriteLine("3. Delete a  Product");
                        Console.WriteLine("4. Search a  Product");
                        Console.WriteLine("5. View All Product");
                        Console.WriteLine("6. Exit");
                        int choice = Convert.ToInt32(Console.ReadLine());

                        switch (choice)
                        {
                            case 1:
                                #region Insert into Products                         
                                try
                                {
                                    con = new SqlConnection(@"server=WIN8\NIKHILINSTANCE;database=trainingDB;user id=sa;password=Password1234");
                                    cmd = new SqlCommand("insert into Products values(@pid,@pname,@category,@price,@available)", con);

                                    Console.WriteLine("Product Id : ");
                                    int pId = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("Product Name");
                                    string pName = Console.ReadLine();

                                    Console.WriteLine("Product Category");
                                    string category = Console.ReadLine();

                                    Console.WriteLine("Product Price");
                                    int price = Convert.ToInt32(Console.ReadLine());






                                    cmd.Parameters.AddWithValue("@pid", pId);
                                    cmd.Parameters.AddWithValue("@pname", pName);
                                    cmd.Parameters.AddWithValue("@category", category);
                                    cmd.Parameters.AddWithValue("@price", price);
                                    cmd.Parameters.AddWithValue("@available", 1);
                                    con.Open();
                                    cmd.ExecuteNonQuery();
                                }
                                catch (SqlException ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                                finally
                                {
                                    con.Close();
                                    con.Dispose();
                                }
                                #endregion
                                break;
                            case 2:
                                #region Update Product

                                try
                                {
                                    con = new SqlConnection(@"server=WIN8\NIKHILINSTANCE;database=trainingDB;user id=sa;password=Password1234");
                                    cmd = new SqlCommand("update products set pPrice=@pPrice, pIsInStock=@isAvaiable where pId=@pId", con);
                                    Console.WriteLine("Enter Product Id to update the product");
                                    int id = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("Is Product Available, true or false");
                                    bool isAvaible = Convert.ToBoolean(Console.ReadLine());
                                    Console.WriteLine("Enter New Product Price");
                                    int newPrice = Convert.ToInt32(Console.ReadLine());

                                    cmd.Parameters.AddWithValue("@pid", id);
                                    cmd.Parameters.AddWithValue("@isAvaiable", isAvaible);
                                    cmd.Parameters.AddWithValue("@pPrice", newPrice);
                                    con.Open();
                                    int count = cmd.ExecuteNonQuery();
                                    if (count == 1)
                                    {
                                        Console.WriteLine("Product updated Successfully");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Product Not Found");
                                    }
                                }
                                catch (SqlException ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                                finally
                                {
                                    con.Close();
                                    cmd.Dispose();
                                    con.Dispose();

                                }
                                #endregion
                                break;
                            case 3:
                                #region Delete By Product Id

                                try
                                {
                                    con = new SqlConnection(@"server=WIN8\NIKHILINSTANCE;database=trainingDB;user id=sa;password=Password1234");
                                    cmd = new SqlCommand("delete from products where pid=@pid", con);
                                    Console.WriteLine("Enter Product Id");
                                    int productToDelete = Convert.ToInt32(Console.ReadLine());
                                    cmd.Parameters.AddWithValue("@pid", productToDelete);
                                    con.Open();
                                    int count = cmd.ExecuteNonQuery();
                                    if (count == 1)
                                    {
                                        Console.WriteLine("Product Deleted Successfully");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Product Not Found, and thus could not be deleted");
                                    }
                                }
                                catch (SqlException ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                                finally
                                {
                                    con.Close();
                                    cmd.Dispose();
                                    con.Dispose();
                                }
                                #endregion
                                break;
                            case 4:
                                #region Slect By Product Id                        
                                try
                                {
                                    con = new SqlConnection(@"server=WIN8\NIKHILINSTANCE;database=trainingDB;user id=sa;password=Password1234");
                                    cmd = new SqlCommand("select * from products where pId=@pId", con);
                                    Console.WriteLine("Enter Product number to view details");
                                    int pId = Convert.ToInt32(Console.ReadLine());
                                    cmd.Parameters.AddWithValue("@pid", pId);

                                    con.Open();
                                    SqlDataReader rd = cmd.ExecuteReader();

                                    if (rd.Read())
                                    {
                                        Console.WriteLine("Product Id : " + rd[0]);
                                        Console.WriteLine("Product Name : " + rd[1]);
                                        Console.WriteLine("Product Category : " + rd[2]);
                                        Console.WriteLine("Product Price : " + rd[3]);
                                        Console.WriteLine("Product Is In Stock : " + rd[4]);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Product Not Found");
                                    }
                                }
                                catch (SqlException ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                                finally
                                {
                                    con.Close();
                                    cmd.Dispose();
                                    con.Dispose();

                                }
                                #endregion
                                break;
                            case 5:
                                #region View All Products

                                try
                                {
                                    con = new SqlConnection(@"server=WIN8\NIKHILINSTANCE;database=trainingDB;user id=sa;password=Password1234");
                                    cmd = new SqlCommand("select * from products", con);
                                    con.Open();
                                    SqlDataReader rd = cmd.ExecuteReader();
                                    while (rd.Read())
                                    {
                                        Console.WriteLine("Product Id : " + rd[0]);
                                        Console.WriteLine("Product Name : " + rd[1]);
                                        Console.WriteLine("Product Category : " + rd[2]);
                                        Console.WriteLine("Product Price : " + rd[3]);
                                        Console.WriteLine("Product Is In Stock : " + rd[4]);
                                        Console.WriteLine("________________________________________________________________");
                                    }
                                }
                                catch (SqlException ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                                finally
                                {
                                    con.Close();
                                    cmd.Dispose();
                                    con.Dispose();

                                }
                                #endregion
                                break;
                            default:
                                Console.WriteLine("Invalid Option");
                                continueAPP = false;
                                break;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Credentials");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
            #endregion                                           

        }
    }
}







