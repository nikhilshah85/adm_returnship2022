﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ado_disconnected
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection("server=WIN8\\NIKHILINSTANCE ; initial catalog=employeeDB; user id=sa;password=Password1234");
        SqlDataAdapter adapter = null;
        DataSet ds = new DataSet();
        DataView dv = null;
        SqlCommandBuilder builder= null;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            adapter = new SqlDataAdapter("select * from employees", con);
            adapter.Fill(ds); //this will open the connection to server, fire the query and get the data into dataset
            
            dataGridView1.DataSource = ds.Tables[0];
            dv = ds.Tables[0].DefaultView; //dataview
            builder = new SqlCommandBuilder(adapter); // this will build queries for insert, update and delete
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ds.Tables[0].WriteXml("employeedetails.xml");
            MessageBox.Show("Data Saved to XML");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dv.RowFilter = "empDesignation = '" + comboBox1.Text + "'"; 
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            dv.RowFilter = "empName like '" + textBox1.Text + "%'";
        }
    }
}
