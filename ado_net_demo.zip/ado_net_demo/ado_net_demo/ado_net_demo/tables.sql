create database trainingDB

use trainingDB

create table Products
(
	pId int primary key,
	pName varchar(20),
	pCategory varchar(20),
	pPrice int,
	pIsInStock bit)

insert into Products values(101,'Pepsi','Cold-Drink',35,1)
select * from Products


create table userDetails
(
	username varchar(20) primary key,
	password varchar(20)
)

insert into userDetails values('Archana','pass@1234')
insert into userDetails values('Megha','pass@12345')
insert into userDetails values('Shilpi','pass@12346')

select * from userDetails
select * from Products



